package paczka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Random;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
	
public class Bob implements Runnable{
	
	//24, 32, 40
	private ArrayList<byte[]> plains;	//to file plains.txt
	private ArrayList<byte[]> puzzles_Bob; //to file puzzle.txt
	
	private String puzzle_mess = "One";
	private SecureRandom sr;
	private int ID;
	private Channel channel;
	private int ID_com;
	private SecretKey session_Key;
	private double iterations;
	protected Bob(int how_many, Channel ch)
	{
		this.iterations = Math.pow((double)2.0, Double.parseDouble(Integer.toString(how_many)));
		
		this.plains = new ArrayList<byte[]>(); 
		
		this.puzzles_Bob = new ArrayList<byte[]>();
		
		this.sr = new SecureRandom(); //let system use prng
		this.ID = this.sr.nextInt(0xFFF); //generate first ID
		
		this.channel = ch;
		this.ID_com = 0;
		
	}
	
	private synchronized void gen_messages() throws NoSuchAlgorithmException, IOException
	{
		System.out.println("Bob: Generating puzzles");
		
		KeyGenerator keygen = KeyGenerator.getInstance("AES");
		SecretKey secretKey;
		
		File f = new File("plains.txt");
		FileOutputStream fos = new FileOutputStream(f);
		String prepare;
		
		
		for(double i = 0; i < iterations; i++)
		{
			//concatenate ID
			puzzle_mess = (ID+"") + puzzle_mess;
			
			//generate key
			
			keygen.init(256);
			secretKey = keygen.generateKey();
			
			//concatenate key
			puzzle_mess = puzzle_mess.concat(secretKey.toString());
			
			//save message 
			//plains.add(puzzle_mess.getBytes()); //tutaj do pliku
			prepare = i+": " + puzzle_mess + "\n";
			fos.write(prepare.getBytes());

			
			puzzle_mess = "One";
			ID = sr.nextInt(0xFFF);
		}
		fos.close();
	}
	
	private synchronized void gen_ciphs() throws Exception //read each line from file encrypt it save to file
	{
		System.out.println("Bob: Encrypting puzzles");
		int randkey = Random.class.newInstance().nextInt(30);
		//generate little key encrypt every puzzle
		
		byte[] tmp = null;

		File f1 = new File("puzzle.txt");
		FileOutputStream fos1 = new FileOutputStream(f1);
		
		File f2 = new File("plains.txt");
		BufferedReader br = new BufferedReader(new FileReader(f2));
		
		String line;
		double d = 0.0;
		char[] hold;
		
		//for(double i = 0; i < iterations; i++)
		try {
		while((line  = br.readLine()) != null) //simple caesar cipher i got enough !!11!
		{
			tmp = new byte[line.length()];
			for(int i = 0; i < line.length(); i++)
			{
				
				hold = line.toCharArray();
				tmp[i] = (byte)((char)(hold[i] + randkey));
				
			}
			line = d + ": " + new String(tmp, "UTF-8") + "\n";
			d += 1.0;
			fos1.write(line.getBytes());	
			randkey = Random.class.newInstance().nextInt(30);
		}
		
		fos1.close();
		br.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	
	//send messages
	private synchronized void send_messages()
	{
		System.out.println("Bob: I'm sending puzzles");
		channel.Access = true;
		//channel.data = this.puzzles_Bob;
		  channel.canRead = true;
		channel.Access = false;
	}
	
	
	private synchronized void receiveID()
	{
		System.out.println("Bob: I'm waiting for ID from Alice");
		while(channel.chosen_id == 0)
		{
			System.out.print("");
		}
		while(true) { if(channel.Access == false) break;}
		channel.Access = true;
		ID_com = channel.chosen_id;
		channel.Access = false;
		
	}
	
	private synchronized void pick_the_key() throws Exception
	{
		File f = new File("plains.txt");
		BufferedReader br = new BufferedReader(new FileReader(f));

		String alices_choice;
		
		for(double i = 0; i < ID_com; i++)
		{
			alices_choice = br.readLine();//new String(plains.get((int)i));
			if(alices_choice.contains(ID_com+""))
			{
				int beg;
				
				beg = alices_choice.indexOf("One");
				beg = beg + 3;
				
				String thekey = alices_choice.substring(beg);

				session_Key = new SecretKeySpec(thekey.getBytes(), 0, thekey.getBytes().length, "AES");
				break;
			}
		}
		System.out.println("Bob: Session key established");
		br.close();
		
	}
	
	public synchronized void run() 
	{
		try {
			
			gen_messages();
			
			gen_ciphs();
			
			send_messages();
			
			receiveID();
			
			pick_the_key();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
}

