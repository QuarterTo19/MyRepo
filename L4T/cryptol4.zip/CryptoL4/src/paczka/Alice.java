package paczka;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;
	
public class Alice implements Runnable{
	
	private Channel channel;
	private ArrayList<byte[]> puzzles;
	private int id;
	private File f;
	private double mess_num = 2.0;
	
	protected Alice(int how_many, Channel ch)
	{
		this.channel = ch;
		this.puzzles = new ArrayList<byte[]>();
		this.mess_num = Math.pow(mess_num, how_many);
	}
	
	private synchronized void get_messages()
	{
		System.out.println("Alice: I'm waiting for the puzzles");
		while(channel.canRead == false)
		{
			System.out.print("");
		}
		
		while(true) { if(channel.Access == false) break;}
		channel.Access = true;
		//puzzles = channel.data;
		channel.canRead = false;
		channel.Access = false;
		

	}
	
	
	private synchronized void pick_and_solve() throws Exception //basic now 
	{
		System.out.println("Alice: I'm picking and solving the puzzle");
		
		f = new File("puzzle.txt");
		
		double p = Random.class.newInstance().nextDouble();
		p = p * mess_num;
		p = Math.ceil(p);
		//System.out.println(p);
		
		BufferedReader br = new BufferedReader(new FileReader(f));
		String line = null;
		double val = 10.0;
		int start = 5;
		
		for(double i = 0.0; i < p; i++)
		{
		
			line = br.readLine();
			if(i % val == 0) { val *=10.0; start += 1;}
		
		}
		line = line.substring(start);
		System.out.println("ALice: Found the puzzle");
		
		int randkey = Random.class.newInstance().nextInt(30);
		char[] ark = line.toCharArray();
		byte[] tmp = null;
		String decoded = "";
		while(true)
		{
			tmp = new byte[line.length()];
			for(int i = 0; i < ark.length; i++)
			{
				tmp[i] = (byte)((char)ark[i] - randkey);
			}
			decoded = new String(tmp, "UTF-8");
			if(decoded.contains("One")) break;
			randkey = Random.class.newInstance().nextInt(30);
			//System.out.println(decoded);
		}
		int beg = decoded.indexOf("One");
		id = Integer.parseInt(decoded.substring(start, beg));
		
		//System.out.println(decoded + " " + id);
		br.close();
	}
	
	
	private synchronized void sendID()
	{
		System.out.println("Alice: Now I'm sending its ID");
		channel.Access = true;
		channel.chosen_id = id;
		channel.Access = false;
				
	}
	
	public synchronized void run() 
	{
		try {
		get_messages();
		
		pick_and_solve();
		
		sendID();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}

